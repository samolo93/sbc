package org.projectfloodlight.openflow.types;

public interface OFHelloElement {

}
