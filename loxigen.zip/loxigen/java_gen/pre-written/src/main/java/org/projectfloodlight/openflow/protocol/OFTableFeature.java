package org.projectfloodlight.openflow.protocol;

public class OFTableFeature {
    // FIXME implement
}
