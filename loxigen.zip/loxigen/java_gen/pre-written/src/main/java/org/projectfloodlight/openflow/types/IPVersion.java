package org.projectfloodlight.openflow.types;

public enum IPVersion {
    IPv4,
    IPv6
}
