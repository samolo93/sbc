package org.projectfloodlight.openflow.protocol;

import org.projectfloodlight.openflow.types.PrimitiveSinkable;

import com.google.common.hash.PrimitiveSink;

public class OFMatchBmap implements PrimitiveSinkable{

    @Override
    public void putTo(PrimitiveSink sink) {
    }

}
