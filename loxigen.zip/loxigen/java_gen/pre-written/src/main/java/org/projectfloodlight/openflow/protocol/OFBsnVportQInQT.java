package org.projectfloodlight.openflow.protocol;

public class OFBsnVportQInQT {

}
