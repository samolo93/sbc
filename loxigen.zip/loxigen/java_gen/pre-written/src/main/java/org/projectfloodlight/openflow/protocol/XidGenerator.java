package org.projectfloodlight.openflow.protocol;

public interface XidGenerator {
    long nextXid();
}
