package org.projectfloodlight.openflow.exceptions;

public class OFShortWrite extends Exception {

    private static final long serialVersionUID = 1L;

}
