//:: include("custom/%s.Builder_normalize_set_wildcards_stanza.java" % msg.name, msg=msg, has_parent=False)
