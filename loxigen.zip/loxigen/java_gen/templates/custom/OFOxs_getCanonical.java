//:: include("custom/OFOxm_getCanonical.java", msg=msg, version=version, has_parent=False)
