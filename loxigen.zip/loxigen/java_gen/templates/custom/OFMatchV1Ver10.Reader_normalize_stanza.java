//:: include("custom/%s.Builder_normalize_stanza.java" % msg.name, msg=msg, has_parent=False)
