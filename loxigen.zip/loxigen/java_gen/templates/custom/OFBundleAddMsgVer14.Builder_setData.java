//:: include("custom/OFBundleAddMsg.Builder_setData.java", msg=msg, version=version, has_parent=False)
